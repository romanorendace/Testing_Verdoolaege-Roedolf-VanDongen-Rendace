package service;

import domain.db.PersonDB;
import domain.db.PersonDBSQL;
import domain.model.Person;

import java.util.List;

public class PersonService {


    private PersonDB db = new PersonDBSQL();


    public Person get(String userId) {
        return db.get(userId);
    }

    public List<Person> getAll() {
        return db.getAll();
    }

    public void add(Person person) {
        db.add(person);
    }

    public void update(Person person) {
        db.update(person);
    }

    public void delete(String userId) {
        db.delete(userId);
    }

    public int getNumberOfPersoens() {
        return db.getNumberOfPersons();
    }

}
